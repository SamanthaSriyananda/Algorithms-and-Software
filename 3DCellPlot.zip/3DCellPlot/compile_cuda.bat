@echo off
setlocal EnableExtensions

set "ROOT=%~dp0"
set "SRC=%~1"

if not defined SRC (
    echo ERROR: No C++ source file provided.
    echo Open your main .cpp file and press Ctrl+Shift+B.
    exit /b 1
)

if not exist "%SRC%" if exist "%ROOT%%SRC%" (
    set "SRC=%ROOT%%SRC%"
)

if not exist "%SRC%" (
    echo ERROR: C++ source not found: %SRC%
    exit /b 1
)

set "BUILD_DIR=%ROOT%build"
set "CUDA_SRC=%ROOT%3DFiles\cudaPinPhedron.cu"
set "EXE=%ROOT%3DCellCudaPlot.exe"
set "CUDA_OBJ=%BUILD_DIR%\cudaPinPhedron.obj"
set "CPP_OBJ=%BUILD_DIR%\cppMain.obj"

echo [1/5] Locating vcpkg...
set "MY_VCPKG=%VCPKG_ROOT%"

if not defined MY_VCPKG if exist "%USERPROFILE%\vcpkg\installed\x64-windows" (
    set "MY_VCPKG=%USERPROFILE%\vcpkg"
)

if not defined MY_VCPKG if exist "C:\vcpkg\installed\x64-windows" (
    set "MY_VCPKG=C:\vcpkg"
)

if not defined MY_VCPKG (
    echo ERROR: Set VCPKG_ROOT to your vcpkg installation.
    exit /b 1
)

set "VCPKG=%MY_VCPKG%\installed\x64-windows"

echo [2/5] Locating Visual Studio...
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"

if not exist "%VSWHERE%" (
    echo ERROR: vswhere.exe not found.
    exit /b 1
)

set "VSPATH="

for /f "usebackq delims=" %%i in (
    `"%VSWHERE%" -latest -products * -property installationPath`
) do set "VSPATH=%%i"

if not defined VSPATH (
    echo ERROR: Visual Studio not found.
    exit /b 1
)

call "%VSPATH%\VC\Auxiliary\Build\vcvarsall.bat" x64

if errorlevel 1 (
    echo ERROR: Visual Studio initialization failed.
    exit /b 1
)

set "CL_EXE="

for /f "delims=" %%i in (
    'where cl.exe 2^>nul'
) do if not defined CL_EXE set "CL_EXE=%%i"

if not defined CL_EXE (
    echo ERROR: cl.exe not found.
    exit /b 1
)

echo [3/5] Checking CUDA and libraries...

if not defined CUDA_PATH (
    echo ERROR: CUDA_PATH is not set.
    exit /b 1
)

set "NVCC=%CUDA_PATH%\bin\nvcc.exe"
set "CUDA_LIB=%CUDA_PATH%\lib\x64"

for %%F in (
    "%NVCC%"
    "%CUDA_LIB%\cudart.lib"
    "%CUDA_SRC%"
    "%VCPKG%\include\GL\freeglut.h"
    "%VCPKG%\lib\freeglut.lib"
) do if not exist "%%~F" (
    echo ERROR: Required file not found: %%~F
    exit /b 1
)

if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"

if errorlevel 1 (
    echo ERROR: Could not create build directory.
    exit /b 1
)

echo [4/5] Compiling CUDA source...

"%NVCC%" -c "%CUDA_SRC%" ^
    -o "%CUDA_OBJ%" ^
    -O3 ^
    -allow-unsupported-compiler ^
    -arch=native ^
    -Wno-deprecated-gpu-targets ^
    -ccbin "%CL_EXE%" ^
    -Xcompiler=/MD

if errorlevel 1 (
    echo ERROR: CUDA compilation failed.
    goto :failed
)

cl.exe /nologo ^
    /EHsc ^
    /MD ^
    /I"%VCPKG%\include" ^
    /c "%SRC%" ^
    /Fo"%CPP_OBJ%"

if errorlevel 1 (
    echo ERROR: C++ compilation failed.
    goto :failed
)

echo [5/5] Linking...

link.exe /NOLOGO ^
    /OUT:"%EXE%" ^
    "%CPP_OBJ%" ^
    "%CUDA_OBJ%" ^
    /LIBPATH:"%CUDA_LIB%" ^
    /LIBPATH:"%VCPKG%\lib" ^
    cudart.lib ^
    opengl32.lib ^
    freeglut.lib

if errorlevel 1 (
    echo ERROR: Linking failed.
    goto :failed
)

call :cleanup

echo BUILD SUCCESSFUL
echo Executable: %EXE%
exit /b 0

:failed
call :cleanup
echo BUILD FAILED.
exit /b 1

:cleanup
if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%" 2>nul
exit /b 0