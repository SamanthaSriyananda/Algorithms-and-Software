@echo off
setlocal

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VSPATH="
for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -property installationPath`) do set "VSPATH=%%i"
if not defined VSPATH (
    echo ERROR: Visual Studio not found.
    exit /b 1
)

call "%VSPATH%\VC\Auxiliary\Build\vcvarsall.bat" x64
if not defined VCINSTALLDIR (
    echo ERROR: vcvarsall did not set up the compiler environment.
    exit /b 1
)

if not exist build mkdir build

echo Compiling CUDA source...

nvcc -c "3DFiles\cudaPinPhedron.cu" ^
    -o "build\cudaPinPhedron.obj" ^
    -O3 ^
    -allow-unsupported-compiler ^
    -arch=native ^
    -Wno-deprecated-gpu-targets ^
    -Xcompiler=/MD

if errorlevel 1 (
    echo ERROR: CUDA compilation failed.
    exit /b 1
)

echo CUDA compilation successful.
exit /b 0