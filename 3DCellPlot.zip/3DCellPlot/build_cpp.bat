@echo off
setlocal

set "SRC=%~1"
if "%SRC%"=="" (
    echo ERROR: No source file given. Open the main .cpp in the editor and rebuild.
    exit /b 1
)

echo [step 1] Locating vcpkg
set "MY_VCPKG=%VCPKG_ROOT%"
if not defined MY_VCPKG set "MY_VCPKG=C:\vcpkg"

echo [step 2] Locating Visual Studio
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VSPATH="
for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -property installationPath`) do set "VSPATH=%%i"
if not defined VSPATH (
    echo ERROR: Visual Studio not found.
    exit /b 1
)

echo [step 3] Initializing compiler environment
call "%VSPATH%\VC\Auxiliary\Build\vcvarsall.bat" x64
if not defined VCINSTALLDIR (
    echo ERROR: vcvarsall did not set up the compiler environment.
    exit /b 1
)

echo [step 4] Checking CUDA and FreeGLUT
set "VCPKG=%MY_VCPKG%\installed\x64-windows"

if not defined CUDA_PATH (
    echo ERROR: CUDA_PATH is not set. Is the CUDA Toolkit installed?
    exit /b 1
)
set "CUDA_LIB=%CUDA_PATH%\lib\x64"

if not exist "%VCPKG%\include\GL\freeglut.h" (
    echo ERROR: FreeGLUT header not found in %VCPKG%
    exit /b 1
)

if not exist "%VCPKG%\lib\freeglut.lib" (
    echo ERROR: FreeGLUT library not found in %VCPKG%
    exit /b 1
)

if not exist build mkdir build

echo [step 5] Building %SRC% ...

cl.exe /nologo /EHsc /MD /Fobuild\ ^
    /I"%VCPKG%\include" ^
    "%SRC%" ^
    build\cudaPinPhedron.obj ^
    /Fe:3DCellCudaPlot.exe ^
    /link ^
    /LIBPATH:"%CUDA_LIB%" ^
    /LIBPATH:"%VCPKG%\lib" ^
    cudart.lib opengl32.lib freeglut.lib

if errorlevel 1 (
    echo ERROR: C++ build or linking failed.
    exit /b 1
)

echo Build successful: 3DCellCudaPlot.exe
exit /b 0