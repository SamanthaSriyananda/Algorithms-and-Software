# 3D Point Cloud Visualization
This program visualizes point clouds in three-dimensional (3D) space and provides multiple options for point-in-polyhedron testing, mesh generation, rendering, and point cloud generation.

## Features
1. Two implementations
   - `3DCellCudaPlot09.cpp`: CPU + NVIDIA CUDA GPU + Intel GPU (OpenGL).
   - `3DCellOGLPlot09.cpp`: CPU + Intel GPU (OpenGL).
2. Two point-in-polyhedron algorithms
   - Ray Casting
   - Winding Number
3. Two meshing modes
   - Triangular mesh
   - Square mesh
4. Two rendering modes
   - Transparent
   - Solid
5. Two point cloud types
   - Polyhedron
   - Sphere
6. Sphere-based point cloud generation
   - Rings
   - Sectors

To select features, follow the instructions given in the table:
+----+-----------------------------+----------------------------------+--------------------------------------+
| No | Feature                     | 3DCellOGLPlot09.cpp              | 3DCellCudaPlot09.cpp                 |
+----+-----------------------------+----------------------------------+--------------------------------------+
| 1  | Ray Casting                 | Line 53: Uncomment               | Line 53: Uncomment                   |
|    |                             | pointInPolyhedronRayCasting()    | cudaPointInPolyhedronRayCasting()    |
|    | Winding Number              | Line 55: Uncomment               | Line 55: Uncomment                   |
|    |                             | pointInPolyhedronWindingNumber() | cudaPointInPolyhedronWindingNumber() |
+----+-----------------------------+----------------------------------+--------------------------------------+
| 2  | Triangular mesh             | Line 5: meshShape = 0            | Line 5: meshShape = 0                |
|    | Square mesh                 | Line 5: meshShape = 1            | Line 5: meshShape = 1                |
+----+-----------------------------+----------------------------------+--------------------------------------+
| 3  | Transparent rendering       | Line 4: meshMode = 0             | Line 4: meshMode = 0                 |
|    | Solid rendering             | Line 4: meshMode = 1             | Line 4: meshMode = 1                 |
+----+-----------------------------+----------------------------------+--------------------------------------+
| 4  | Enhanced sphere point cloud | Line 13: Uncomment loader        | Line 13: Uncomment loader            |
|    | Standard sphere point cloud | Line 16: Uncomment loader        | Line 16: Uncomment loader            |
|    | External point cloud        | Line 14: Uncomment loader        | Line 14: Uncomment loader            |
+----+-----------------------------+----------------------------------+--------------------------------------+
| 5  | Generate enhanced sphere    | Line 12: Uncomment               | Line 12: Uncomment                   |
|    | Generate standard sphere    | Line 15: Uncomment               | Line 15: Uncomment                   |
+----+-----------------------------+----------------------------------+--------------------------------------+
| 6  | Set rings and sectors       | Lines 12, 15: Edit arguments     | Lines 12, 15: Edit arguments         |
+----+-----------------------------+----------------------------------+--------------------------------------+
| 7  | Manual test point           | Line 49: Uncomment               | Line 49: Uncomment                   |
|    | Interactive point input     | Lines 45-47: Keep active         | Lines 45-47: Keep active             |
+----+-----------------------------+----------------------------------+--------------------------------------+
| 8  | Pause after each test       | Line 62: Uncomment _getch()      | Line 62: Uncomment _getch()          |
+----+-----------------------------+----------------------------------+--------------------------------------+


## Implementation and Build Instructions

### 1. `3DCellCudaPlot09.cpp`
This implementation uses the CPU, an NVIDIA GPU with CUDA, and an Intel GPU with OpenGL.
In the configured development environment, press Ctrl + Alt + B to build the program.

### 2. `3DCellOGLPlot09.cpp`
This implementation uses the CPU and Intel GPU with OpenGL.
In the configured development environment, press Ctrl + Alt + N to compile and execute the program.

## Applications
1. Point-in-cloud testing: Determine whether a given point lies inside a point cloud or a polyhedral region, supporting applications such as data visualization and anomaly detection.
2. Wireless coverage analysis: Determine whether a wireless mobile device (UE), flying object, or sensor is located within a defined cellular coverage region.
3. Boundary determination: Identify or analyze the boundaries of a point cloud.
4. Engineering and computer graphics: Support 3D visualization, geometric analysis, and related engineering applications.

(R) Samantha Sriyananda
Contact: mgssriyananda@gmail.com