// ------------------------------------------------------------
// Display and reshape
// ------------------------------------------------------------
#ifndef DISPLAY_H
#define DISPLAY_H

#include "Draw3DCell.h"

extern vector<Point3D> spherePoints;
extern int rings;
extern int sectors;
extern int meshMode;

// ------------------------------------------------------------
// Display
// ------------------------------------------------------------

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    applyMouseProjection();

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glTranslatef(cameraX, cameraY, -3.5f);
    glRotatef(rotateX, 1.0f, 0.0f, 0.0f);
    glRotatef(rotateY, 0.0f, 1.0f, 0.0f);
    glRotatef(rotateZ, 0.0f, 0.0f, 1.0f);

    // drawSphereMesh(rings, sectors, spherePoints);
    drawSphereMesh(rings, sectors, spherePoints, meshMode);
    drawAxes();

    glutSwapBuffers();
}

// ------------------------------------------------------------
// Reshape
// ------------------------------------------------------------

void reshape(int width, int height)
{
    if (height == 0) height = 1;

    float aspect = static_cast<float>(width) / static_cast<float>(height);

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    if (aspect >= 1.0f)
        glOrtho(-viewScale * aspect, viewScale * aspect, -viewScale, viewScale, -10.0f, 10.0f); // viewScale is defined in "MouseCtrls.h"
    else
        glOrtho(-viewScale, viewScale, -viewScale / aspect, viewScale / aspect, -10.0f, 10.0f);

    glMatrixMode(GL_MODELVIEW);
}

#endif