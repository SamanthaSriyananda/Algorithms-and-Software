// ------------------------------------------------------------
// Utility functions
// ------------------------------------------------------------
#ifndef UTILITYFNS_H
#define UTILITYFNS_H

#include "Point3D.h"
#include <vector>
#include <cmath>

inline double xyRadius(const Point3D& p)
{
    return sqrt(static_cast<double>(p.x) * static_cast<double>(p.x) + static_cast<double>(p.y) * static_cast<double>(p.y));
}

inline double xyAngle(const Point3D& p)
{
    return atan2(static_cast<double>(p.y), static_cast<double>(p.x));
}

inline double angleDifference(double a, double b, double PI, double TWO_PI)
{
    double d = a - b;

    while (d > PI)
        d -= TWO_PI;

    while (d < -PI)
        d += TWO_PI;

    return d;
}

inline double calculateMean(const std::vector<double>& values)
{
    if (values.empty())
        return 0.0;

    double sum = 0.0;

    for (double v : values)
        sum += v;

    return sum / values.size();
}

inline double calculateStdDev(const std::vector<double>& values, double mean)
{
    if (values.empty())
        return 0.0;

    double sum = 0.0;

    for (double v : values)
        sum += (v - mean) * (v - mean);

    return sqrt(sum / values.size());
}

#endif