// ------------------------------------------------------------
// Keyboard controls
// ------------------------------------------------------------

#ifndef KEYBOARDCTRLS_H
#define KEYBOARDCTRLS_H

float rotateX = 30.0f;
float rotateY = -20.0f;
float rotateZ = 0.0f;

void keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
        case 27:
            exit(0);
            break;

        case 'w':
            rotateX -= 5.0f;
            break;

        case 's':
            rotateX += 5.0f;
            break;

        case 'a':
            rotateY -= 5.0f;
            break;

        case 'd':
            rotateY += 5.0f;
            break;

        case 'q':
            rotateZ -= 5.0f;
            break;

        case 'e':
            rotateZ += 5.0f;
            break;
    }

    glutPostRedisplay(); // Rredraw the screen if a key changed a visual element
}

#endif