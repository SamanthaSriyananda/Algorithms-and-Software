// ------------------------------------------------------------
// Draw XYZ axes
// ------------------------------------------------------------

#ifndef DRAWXYZ_H
#define DRAWXYZ_H

#include "DrawText.h"

void drawAxes()
{
    glDisable(GL_LIGHTING); // If enabled, for lines (not surfaces), glColor3f() no longer directly determines the final color
    glLineWidth(2.0f);

    // X axis
    glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);
    glVertex3f(-1.4f, 0.0f, 0.0f);
    glVertex3f(1.4f, 0.0f, 0.0f);
    glEnd();

    // Y axis
    glColor3f(0.0f, 0.8f, 0.0f);
    glBegin(GL_LINES);
    glVertex3f(0.0f, -1.4f, 0.0f);
    glVertex3f(0.0f, 1.4f, 0.0f);
    glEnd();

    // Z axis
    glColor3f(0.0f, 0.0f, 1.0f);
    glBegin(GL_LINES);
    glVertex3f(0.0f, 0.0f, -1.4f);
    glVertex3f(0.0f, 0.0f, 1.4f);
    glEnd();

    glColor3f(1.0f, 0.0f, 0.0f);
    drawText(1.4f, 0.0f, 0.0f, "X");

    glColor3f(0.0f, 0.8f, 0.0f);
    drawText(0.0f, 1.4f, 0.0f, "Y");

    glColor3f(0.0f, 0.0f, 1.0f);
    drawText(0.0f, 0.0f, 1.4f, "Z");

    glLineWidth(1.0f);

    glEnable(GL_LIGHTING);
}


#endif