// ------------------------------------------------------------
// Read coordinates and to check the input
// ------------------------------------------------------------
#ifndef READXYZ_H
#define READXYZ_H

#include <thread>               // To check the input
#include <string>
#include <conio.h>              // To check the input (for _getch())

// ------------------------------------------------------------
// Read coordinate and detect Esc
// ------------------------------------------------------------
bool readCoordinates(const char* prompt, float& value) {
    string input;
    cout << prompt << flush;

    while (true) {
        int ch = _getch(); // Read a keyboard keystroke

        // Esc key: terminate immediately
        if (ch == 27) {
            cout << "\n\nExiting program ...\n\n";
            SetConsoleOutputCP(CP_UTF8);
            cout << "\u00A9 Samantha Sriyananda (All rights reserved)\n\n";
            exit(0);
        }
        // Enter key: finish coordinate
        else if (ch == '\r' || ch == '\n') {
            try { // Generally try()catch() is to be used with stof() to catch "thraw" messages given by the function
                size_t pos;
                value = std::stof(input, &pos);  // stof() = converts string to float.
                // Value of pos changes from the default (pos = position of the first non string character)

                // Reject input containing extra characters
                if (pos != input.size())
                    throw invalid_argument("Invalid number");

                cout << '\n';
                return false;
            }
            catch (...) {
                cout << "\nInvalid number. Try again: " << flush;
                input.clear();
            }
        }
        // Backspace key: delete the last character
        else if ((ch == '\b' || ch == 127) && !input.empty()) {
            input.pop_back();
            cout << "\b \b" << flush; // Erase the character from the console
        }
        // Accept digits, signs, decimal point, and exponent
        else if ((ch >= '0' && ch <= '9') ||
                 ch == '-' || ch == '+' || ch == '.') {
            input += static_cast<char>(ch);
            cout << static_cast<char>(ch) << flush;
        }
    }
    return true;
}

#endif