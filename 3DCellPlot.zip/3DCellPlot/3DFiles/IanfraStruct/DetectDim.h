// ------------------------------------------------------------
// Load the sphere points and detect mesh dimensions
// ------------------------------------------------------------
#ifndef DETECTDIM_H
#define DETECTDIM_H

#include "UtilityFns.h"
#include <vector>
#include <iostream>
#include <fstream>
#include "Point3D.h"

struct MeshDimensions
{
    std::vector<Point3D> spherePoints;

    int sectors = 0;
    int rings = 0;
    int pointsPerRing = 0;
    int numPoints = 0;
};


// ------------------------------------------------------------
// Load the sphere points
// ------------------------------------------------------------
inline void loadSpherePoints(MeshDimensions &result, const char* filename)
{
    std::ifstream pfile(filename);

    if (!pfile)
    {
        std::cerr << "Error: Could not open " << filename << std::endl;
        exit(1);
    }

    Point3D p;
    result.spherePoints.clear();

    while (pfile >> p.x >> p.y >> p.z)
        result.spherePoints.push_back(p);

    pfile.close();

    result.numPoints = static_cast<int>(result.spherePoints.size());

    std::cout << "Loaded " << result.numPoints << " data points.\n";
}


// ------------------------------------------------------------
// Automatically detect sectors
// ------------------------------------------------------------
inline void detectSectors(MeshDimensions &result, double PI, double TWO_PI)
{
    int firstNonPole = -1;
    int numPoints = static_cast<int>(result.spherePoints.size());

    // Find first point away from north pole
    for (int i = 0; i < numPoints; i++)
    {
        if (xyRadius(result.spherePoints[i]) > 1e-5) // Utility function to check if the point is not at the pole
        {
            firstNonPole = i;
            break;
        }
    }

    if (firstNonPole < 0)
    {
        std::cerr << "Could not find a non-pole point.\n";
        exit(1);
    }

    double startAngle = xyAngle(result.spherePoints[firstNonPole]);
    double previousAngle = startAngle;
    double totalAngle = 0.0;

    for (int i = firstNonPole + 1; i < numPoints; i++)
    {
        double currentAngle = xyAngle(result.spherePoints[i]);
        double delta = angleDifference(currentAngle, previousAngle, PI, TWO_PI);

        if (delta < 0.0)
            break;

        totalAngle += delta;
        previousAngle = currentAngle;

        if (totalAngle >= TWO_PI - 0.20)
        {
            result.pointsPerRing = i - firstNonPole + 1;
            result.sectors = result.pointsPerRing - 1;
            break;
        }
    }

    if (result.pointsPerRing == 0)
    {
        std::cerr << "Could not automatically detect sectors.\n";
        exit(1);
    }

    std::cout << "\nAutomatic sector detection\n";
    std::cout << "First non-pole point = " << firstNonPole << "\n";
    std::cout << "Points per ring = " << result.pointsPerRing << "\n";
    std::cout << "Detected sectors = " << result.sectors << "\n";
}


// ------------------------------------------------------------
// Automatically detect rings
// ------------------------------------------------------------
inline void detectRings(MeshDimensions &result)
{
    int numPoints = static_cast<int>(result.spherePoints.size());
    int totalRows = numPoints / result.pointsPerRing;

    result.rings = 0;

    for (int row = 0; row < totalRows; row++)
    {
        int start = row * result.pointsPerRing;
        int end = start + result.pointsPerRing;

        if (end > numPoints) 
            break;

        std::vector<double> radii;

        for (int i = start; i < end; i++)
            radii.push_back(xyRadius(result.spherePoints[i]));

        double mean = calculateMean(radii);
        double stdDev = calculateStdDev(radii, mean);

        // Pole row
        if (mean < 1e-5)
        {
            result.rings++;
            continue;
        }

        // Latitude row
        double variation = stdDev / mean;

        if (variation < 0.20)
            result.rings++;
        else
            break;
    }

    // Rows = rings + 1
    if (result.rings > 0)
        result.rings--;

    std::cout << "\nDetected latitude rows = " << result.rings + 1 << "\n";
    std::cout << "Detected rings = " << result.rings << "\n";
}


// ------------------------------------------------------------
// Detect complete mesh dimensions
// ------------------------------------------------------------

inline MeshDimensions detectMeshDimensions(const char* filename, double PI, double TWO_PI)
{
    MeshDimensions result;
    loadSpherePoints(result, filename);
    detectSectors(result, PI, TWO_PI);
    detectRings(result);

    int meshPoints = (result.rings + 1) * (result.sectors + 1);

    if (meshPoints > result.numPoints)
    {
        std::cerr << "Error: Detected mesh dimensions exceed data size.\n";
        exit(1);
    }

    std::cout << "\n----------------------------------------\n";
    std::cout << "Detected sphere mesh\n";
    std::cout << "Rings       = " << result.rings << "\n";
    std::cout << "Sectors     = " << result.sectors << "\n";
    std::cout << "Grid points = " << meshPoints << "\n";
    std::cout << "Total file  = " << result.numPoints << "\n";
    std::cout << "Extra data  = " << result.numPoints - meshPoints << "\n";
    std::cout << "----------------------------------------\n";

    return result;
}

#endif