// ------------------------------------------------------------
// Infrastructure header file
// ------------------------------------------------------------
#ifndef INFRASTRUCT_H
#define INFRASTRUCT_H


#include <GL/freeglut.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <random>
#include <thread>               // To check the input (ReadXYZ.h)

#include "OpenGLIni.h"
#include "DrawXYZ.h"
#include "DrawLabels.h"
#include "DetectDim.h"
#include "ReadXYZ.h"
#include "KeyboardCtrls.h"
#include "MouseCtrls.h"
#include "SpherePoints.h"
#include "SpherePointsPlus.h"

using namespace std;

void cudaPointInPolyhedronRayCasting(const MeshDimensions& mesh, const Point3D& tp); // For "CudaClassifier.cu"
void cudaPointInPolyhedronWindingNumber(const MeshDimensions& mesh, const Point3D& tp); // For "CudaClassifier.cu"

vector<Point3D> spherePoints;
Point3D tp; // Test point
int decision; // Algorithm decision

int numPoints = 0, rings = 0, sectors = 0;

const double PI = 3.14159265358979323846;
const double TWO_PI = 2.0 * PI;

#endif