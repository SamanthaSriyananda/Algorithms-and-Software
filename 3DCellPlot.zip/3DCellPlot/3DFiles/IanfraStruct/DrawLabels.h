// ------------------------------------------------------------
// Draw Sensor/UE labels
// ------------------------------------------------------------
#ifndef DRAW_LABELS_H 
#define DRAW_LABELS_H

#include <vector>
#include <cmath>
#include "Point3D.h"

using namespace std;


void drawSensorLabels(const vector<Point3D>& spherePoints)
{
    glDisable(GL_LIGHTING);
    int numPoints = spherePoints.size();

    const int labelIndices[] = {219, 239, 259, 279};  // Label positions: 20th, 40th, 60th, and 80th datapoints
    const char* labels[] = {"Sensor/UE: 1", "Sensor/UE: 2", "Sensor/UE: 3", "Sensor/UE: 4" };
    glColor3f(0.8f, 0.4f, 0.2f);

    for (int i = 0; i < 4; i++)
    {
        int index = labelIndices[i];

        if (index >= numPoints) // Check that the datapoint exists
            continue;

        Point3D p = spherePoints[index];

        float offset = 0.08f; // Move the label slightly away from the point

        float length = sqrt(
            p.x * p.x +
            p.y * p.y +
            p.z * p.z
        );

        float x = p.x;
        float y = p.y;
        float z = p.z;

        if (length > 1e-5f)
        {
            x += offset * p.x / length;
            y += offset * p.y / length;
            z += offset * p.z / length;
        }

        drawText(x, y, z, labels[i]);
    }

    glEnable(GL_LIGHTING);
}

#endif