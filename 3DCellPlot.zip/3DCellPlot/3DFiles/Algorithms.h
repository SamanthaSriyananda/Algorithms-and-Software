// ------------------------------------------------------------
// Algorithms
// ------------------------------------------------------------
#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include "Draw3DCell.h" // For square/triangular mesh (transparent and solid)
#include "DispNReshape.h"
#include "PinPhedron.h" // 3D Point-in-Polyhedron - Ray Casting / Winding Number (both with triangular mesh)

#endif