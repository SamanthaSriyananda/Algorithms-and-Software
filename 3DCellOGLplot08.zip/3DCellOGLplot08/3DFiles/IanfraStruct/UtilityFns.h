// ------------------------------------------------------------
// Utility functions
// ------------------------------------------------------------
#ifndef UTILITYFNS_H
#define UTILITYFNS_H

#include "Point3D.h"
#include <vector>
#include <cmath>

double xyRadius(const Point3D& p)
{
    return sqrt(static_cast<double>(p.x) * static_cast<double>(p.x) + static_cast<double>(p.y) * static_cast<double>(p.y));
}

double xyAngle(const Point3D& p)
{
    return atan2(static_cast<double>(p.y), static_cast<double>(p.x));
}

double angleDifference(double a, double b, double PI, double TWO_PI)
{
    double d = a - b;

    while (d > PI)
        d -= TWO_PI;

    while (d < -PI)
        d += TWO_PI;

    return d;
}

double calculateMean(const vector<double>& values)
{
    if (values.empty())
        return 0.0;

    double sum = 0.0;

    for (double v : values)
        sum += v;

    return sum / values.size();
}

double calculateStdDev(const vector<double>& values, double mean)
{
    if (values.empty())
        return 0.0;

    double sum = 0.0;

    for (double v : values)
        sum += (v - mean) * (v - mean);

    return sqrt(sum / values.size());
}

#endif