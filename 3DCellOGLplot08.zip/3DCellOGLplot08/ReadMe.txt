This program can be used to determine whether a given wireless mobile device/UE is within a given cell coverage area.
1. In 3DCellOGLplot08.cpp, select the line 60 or 62 based on the algorithm you want to use to determine the location.
	Two algorithms: Ray Casting, Winding Number
2. Compile 3DCellOGLplot08.cpp and follow the instructions


1. PHYSICAL TREE
============================================================
3DPlot/
├── 3DCellOGLplot08.cpp
├── Parameters.txt
├── Points_Cloud.txt
│
├── .vscode/
│   ├── c_cpp_properties.json
│   ├── keybindings.json
│   ├── tasks.json
│   └── tasksBK.json
│
└── 3DFiles/
    ├── Algorithms.h
    ├── DispNReshape.h
    ├── Draw3DCell.h
    ├── PinPhedron.h
    │
    └── IanfraStruct/
        ├── DetectDim.h
        ├── DrawLabels.h
        ├── DrawText.h
        ├── DrawXYZ.h
        ├── IanfraStruct.h
        ├── IanfraStructBK.h
        ├── KeyboardCtrls.h
        ├── MouseCtrls.h
        ├── OpenGLIni.h
        ├── Point3D.h
        ├── ReadXYZ.h
        ├── ReadXYZBK.h
        ├── SpherePoints.h
        ├── SpherePointsPlus.h
        ├── UtilityFns.h
        ├── tempCodeRunnerFile.h
        ├── sphere_points.txt
        └── sphere_pointsPlus.txt

NOTES:
- Main source: 3DCellOGLplot08.cpp
- Parameters.txt documents some earlier version-07 details.
- IanfraStructBK.h and ReadXYZBK.h are backup files.
- tempCodeRunnerFile.h appears to be a temporary development file.
- tasksBK.json is a backup build-task configuration.
- The active mesh input is sphere_pointsPlus.txt.
- Points_Cloud.txt is an alternative mesh input.
- sphere_points.txt is another alternative mesh input.


============================================================
2. LOGICAL TREE
============================================================
3D Point-in-Polyhedron OpenGL Application
│
├── Application Entry
│   └── 3DCellOGLplot08.cpp
│       └── main()
│
├── Infrastructure / Shared State
│   └── IanfraStruct.h
│       ├── Point3D
│       ├── MeshDimensions
│       ├── spherePoints
│       ├── tp
│       ├── decision
│       ├── rings / sectors
│       ├── meshMode / meshShape
│       ├── Camera and rotation variables
│       ├── PI / TWO_PI
│       └── OpenGL, STL and thread dependencies
│
├── Mesh Input / Dimension Detection
│   └── DetectDim.h
│       ├── loadSpherePoints()
│       ├── detectSectors()
│       ├── detectRings()
│       └── detectMeshDimensions()
│
├── Coordinate Input
│   └── ReadXYZ.h
│       └── readCoordinates()
│           ├── Read X coordinate
│           ├── Read Y coordinate
│           └── Read Z coordinate
│
├── Mesh Generation
│   ├── SpherePoints.h
│   │   └── SpherePoints()
│   │
│   └── SpherePointsPlus.h
│       └── SpherePointsPlus()
│
├── Point-in-Polyhedron Algorithms
│   └── PinPhedron.h
│       │
│       ├── Shared Geometry Helpers
│       │   ├── pp_dot()
│       │   ├── pp_length()
│       │   └── pp_pointOnTriangle()
│       │
│       ├── Ray Casting
│       │   ├── pp_rayTriangle()
│       │   ├── pp_countUniqueRayHits()
│       │   └── pointInPolyhedronRayCasting()
│       │
│       └── Winding Number
│           ├── pp_triangleSolidAngle()
│           ├── pp_windingNumber()
│           └── pointInPolyhedronWindingNumber()
│
├── Rendering
│   ├── DispNReshape.h
│   │   ├── display()
│   │   └── reshape()
│   │
│   ├── Draw3DCell.h
│   │   ├── drawShadedMesh()
│   │   ├── drawTransparentMesh()
│   │   ├── drawWireframe()
│   │   ├── drawVertices()
│   │   ├── drawTestPoint()
│   │   └── drawSphereMesh()
│   │
│   ├── DrawXYZ.h
│   │   └── drawAxes()
│   │
│   ├── DrawLabels.h
│   │   └── drawSensorLabels()
│   │
│   └── DrawText.h
│       └── drawText()
│
├── User Input / Camera Controls
│   ├── KeyboardCtrls.h
│   │   └── keyboard()
│   │
│   └── MouseCtrls.h
│       ├── applyZoom()
│       ├── applyMouseProjection()
│       ├── mouseButton()
│       ├── mouseMotion()
│       ├── installMouseWindowProc()
│       └── resetMouseView()
│
├── OpenGL Initialization
│   └── OpenGLIni.h
│       └── initOpenGL()
│
└── Utilities
    └── UtilityFns.h
        ├── xyRadius()
        ├── xyAngle()
        ├── angleDifference()
        ├── calculateMean()
        └── calculateStdDev()

IMPORTANT:
- Mesh generation functions exist but are not called by main().
- The active point classification algorithm is Ray Casting.
- Winding Number is implemented but commented out in main().
- drawTestPoint() exists but is not called by the current display().


============================================================
3. DEPENDENCY TREE
============================================================

SOURCE-LEVEL INCLUDE TREE
─────────────────────────

3DCellOGLplot08.cpp
│
├── 3DFiles/IanfraStruct/IanfraStruct.h
│   │
│   ├── OpenGLIni.h
│   │   └── initOpenGL()
│   │
│   ├── DrawXYZ.h
│   │   └── DrawText.h
│   │       └── drawText()
│   │
│   ├── DrawLabels.h
│   │   └── Point3D.h
│   │
│   ├── DetectDim.h
│   │   ├── UtilityFns.h
│   │   │   └── Point3D.h
│   │   └── MeshDimensions / Point3D
│   │
│   ├── ReadXYZ.h
│   │   └── readCoordinates()
│   │
│   ├── KeyboardCtrls.h
│   │   └── keyboard()
│   │
│   ├── MouseCtrls.h
│   │   ├── mouseButton()
│   │   ├── mouseMotion()
│   │   ├── applyZoom()
│   │   ├── applyMouseProjection()
│   │   ├── installMouseWindowProc()
│   │   └── resetMouseView()
│   │
│   ├── SpherePoints.h
│   │   └── SpherePoints()
│   │
│   └── SpherePointsPlus.h
│       └── SpherePointsPlus()
│
└── 3DFiles/Algorithms.h
    │
    ├── Draw3DCell.h
    │   ├── drawShadedMesh()
    │   ├── drawTransparentMesh()
    │   ├── drawWireframe()
    │   ├── drawVertices()
    │   ├── drawTestPoint()
    │   └── drawSphereMesh()
    │
    ├── DispNReshape.h
    │   ├── display()
    │   │   ├── drawSphereMesh()
    │   │   └── drawAxes()
    │   └── reshape()
    │
    └── PinPhedron.h
        ├── pp_dot()
        ├── pp_length()
        ├── pp_pointOnTriangle()
        ├── pp_rayTriangle()
        ├── pp_countUniqueRayHits()
        ├── pointInPolyhedronRayCasting()
        ├── pp_triangleSolidAngle()
        ├── pp_windingNumber()
        └── pointInPolyhedronWindingNumber()


DIRECT FUNCTIONAL DEPENDENCIES
──────────────────────────────

main()
 ├── detectMeshDimensions()
 │    └── loadSpherePoints()
 │         └── Reads sphere_pointsPlus.txt
 │
 ├── initOpenGL()
 ├── installMouseWindowProc()
 ├── glutDisplayFunc(display)
 ├── glutReshapeFunc(reshape)
 ├── glutKeyboardFunc(keyboard)
 ├── glutMouseFunc(mouseButton)
 ├── glutMotionFunc(mouseMotion)
 ├── readCoordinates()
 ├── pointInPolyhedronRayCasting()
 └── glutMainLoop()


display()
 ├── Apply projection and camera transformations
 ├── drawSphereMesh()
 │    ├── drawShadedMesh()
 │    ├── drawTransparentMesh()
 │    ├── drawWireframe()
 │    └── drawVertices()
 ├── drawAxes()
 └── glutSwapBuffers()


pointInPolyhedronRayCasting()
 ├── pp_pointOnTriangle()
 ├── pp_rayTriangle()
 └── pp_countUniqueRayHits()


pointInPolyhedronWindingNumber()
 ├── pp_pointOnTriangle()
 └── pp_windingNumber()
      └── pp_triangleSolidAngle()


EXTERNAL LIBRARY DEPENDENCIES
─────────────────────────────

Application
 ├── C++ standard library
 │    ├── vector
 │    ├── fstream / iostream
 │    ├── algorithm
 │    ├── cmath
 │    ├── random
 │    └── thread
 │
 ├── FreeGLUT
 │    ├── Window management
 │    ├── Display callbacks
 │    ├── Keyboard callbacks
 │    └── Mouse callbacks
 │
 ├── OpenGL
 │    ├── 3D rendering
 │    ├── Lighting and materials
 │    ├── Depth testing
 │    └── Projection transformations
 │
 └── Windows API
      ├── windows.h
      ├── Mouse-wheel / gesture integration
      └── GDI-related linkage


DATA DEPENDENCY
───────────────

sphere_pointsPlus.txt
        │
        ▼
loadSpherePoints()
        │
        ▼
MeshDimensions
 ├── spherePoints
 ├── rings
 ├── sectors
 └── numPoints
        │
        ├──────────────────┐
        ▼                  ▼
   display()         Point-in-polyhedron test
        │                  │
        ▼                  ▼
   OpenGL mesh          decision
                           │
                           ▼
                      Console result